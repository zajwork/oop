#ifndef GENERAL_STORE_H
#define GENERAL_STORE_H

#include <iostream>
#include <ctime>

class General_Store {
private:
    int item_code;
    char* item_name;
    int price;
    tm expiration_date;
    tm current_date;

public:
    General_Store(int code, const char* name, int p, int exp_year, int exp_month, int exp_day);
    General_Store(const General_Store& other);
    ~General_Store();

    int getItemCode() const;
    const char* getItemName() const;
    int getPrice() const;
    void setItemName(const char* name);

    int check_date() const;

    void display() const;
};

#endif
