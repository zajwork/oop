#include "General_Store.h"
#include <cstring>
#include <ctime>

// Parameterized constructor
General_Store::General_Store(int code, const char *name, int p, int exp_year, int exp_month, int exp_day)
    : item_code(code), price(p) {
    item_name = new char[strlen(name) + 1];
    std::strcpy(item_name, name);

    expiration_date.tm_year = exp_year - 1900;
    expiration_date.tm_mon = exp_month - 1;
    expiration_date.tm_mday = exp_day;

    // Assuming current date is today
    time_t now = time(0);
    tm *local_time = localtime(&now);
    current_date = *local_time;
}

// Copy constructor (Deep copy)
General_Store::General_Store(const General_Store &other)
    : item_code(other.item_code), price(other.price), current_date(other.current_date) {
    item_name = new char[std::strlen(other.item_name) + 1];
    std::strcpy(item_name, other.item_name);
    expiration_date = other.expiration_date;
}

// Destructor
General_Store::~General_Store() {
    delete[] item_name;
}

// Getter functions
int General_Store::getItemCode() const {
    return item_code;
}

const char *General_Store::getItemName() const {
    return item_name;
}

int General_Store::getPrice() const {
    return price;
}

// Function to check days remaining till expiration date
int General_Store::check_date() const {
    time_t exp_time = mktime(const_cast<tm*>(&expiration_date));
    time_t current_time = mktime(const_cast<tm*>(&current_date));
    double seconds_diff = difftime(exp_time, current_time);
    return static_cast<int>(seconds_diff / (60 * 60 * 24)); // Convert seconds to days
}

// Display function
void General_Store::display() const {
    std::cout << "Item Code: " << item_code << std::endl;
    std::cout << "Item Name: " << item_name << std::endl;
    std::cout << "Price: " << price << std::endl;
    std::cout << "Days remaining till expiration: " << check_date() << " days" << std::endl;
}
