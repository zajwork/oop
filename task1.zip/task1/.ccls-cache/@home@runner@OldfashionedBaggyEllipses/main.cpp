#include <iostream>
#include "General_Store.h"

int main() {
    int code1, code2, price1, price2, exp_date1, exp_date2, curr_date1, curr_date2;
    char name1[100], name2[100];

    // Get data for object1 from user
    std::cout << "Enter details for object 1:" << std::endl;
    std::cout << "Enter item code: ";
    std::cin >> code1;

    std::cout << "Enter item name: ";
    std::cin.ignore(); // Ignore the newline character in the buffer
    std::cin.getline(name1, 100);

    std::cout << "Enter price: ";
    std::cin >> price1;

    std::cout << "Enter expiration date: ";
    std::cin >> exp_date1;

    std::cout << "Enter current date: ";
    std::cin >> curr_date1;

    // Create object1 with user input
    General_Store object1(code1, name1, price1, exp_date1, curr_date1);

    // Get data for object2 from user
    std::cout << "\nEnter details for object 2:" << std::endl;
    std::cout << "Enter item code: ";
    std::cin >> code2;

    std::cout << "Enter item name: ";
    std::cin.ignore(); // Ignore the newline character in the buffer
    std::cin.getline(name2, 100);

    std::cout << "Enter price: ";
    std::cin >> price2;

    std::cout << "Enter expiration date: ";
    std::cin >> exp_date2;

    std::cout << "Enter current date: ";
    std::cin >> curr_date2;

    // Create object2 with user input
    General_Store object2(code2, name2, price2, exp_date2, curr_date2);

    // Display data of both objects
    std::cout << "\nObject 1 details:\n";
    object1.display();

    std::cout << "\nObject 2 details:\n";
    object2.display();

    return 0;
}
