#include "General_Store.h"
#include <iostream>

int main() {
    int code, price, exp_year, exp_month, exp_day;
    char name[50];

    std::cout << "Enter item code: ";
    std::cin >> code;
    std::cout << "Enter item name: ";
    std::cin.ignore(); // to clear the input buffer
    std::cin.getline(name, 50);
    std::cout << "Enter price: ";
    std::cin >> price;
    std::cout << "Enter expiration year: ";
    std::cin >> exp_year;
    std::cout << "Enter expiration month: ";
    std::cin >> exp_month;
    std::cout << "Enter expiration day: ";
    std::cin >> exp_day;

    General_Store object1(code, name, price, exp_year, exp_month, exp_day);
    General_Store object2 = object1;

    char new_name[50];
    std::cout << "Enter new item name for object2: ";
    std::cin.ignore(); // to clear the input buffer
    std::cin.getline(new_name, 50);
    object2.setItemName(new_name);

    object1.display();
    std::cout << std::endl;
    object2.display();

    return 0;
}